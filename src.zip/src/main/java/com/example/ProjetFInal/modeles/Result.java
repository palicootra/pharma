package com.example.ProjetFInal.modeles;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
public class Result {
    private String message;
    private int code;

}
