package com.example.ProjetFInal.enumeration;

import org.springframework.data.mongodb.core.mapping.Document;


public enum Forme {
    CIRO,
    COMPRIME ;


}
